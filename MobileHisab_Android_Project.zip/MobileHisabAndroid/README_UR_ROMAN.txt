MOBILE HISAB ANDROID PROJECT
============================

Yeh Android Studio project hai. APK abhi compiled nahi hai.

APP FEATURES
- Mobile model, IMEI/serial, seller, buyer
- Purchase price/date and sale price/date
- Automatic profit/loss on sold mobiles
- Stock list and monthly reports
- CSV export and JSON backup/restore
- Existing scanner/photo reading feature (browser/WebView support par depend karta hai)

IMPORTANT DATA NOTE
Records is app ke local WebView/browser storage mein save hote hain. App data clear ya uninstall karne se records delete ho sakte hain. Regular backup zaroor banayein. Cloud sync included nahi hai.

APK BUILD KARNE KA AASAN TAREEQA (COMPUTER REQUIRED)
1. Android Studio install karein.
2. Is ZIP ko extract karein.
3. Android Studio > Open > extracted MobileHisab folder select karein.
4. Gradle sync complete hone dein (internet required).
5. Build > Build Bundle(s) / APK(s) > Build APK(s) par click karein.
6. APK yahan milegi: app/build/outputs/apk/debug/app-debug.apk
7. APK ko apne Android phone mein transfer karein, file open karein, aur Android ke prompt par installation allow karein.

GitHub Actions alternative:
Project ko apne GitHub repository mein upload karne ke baad Actions tab mein "Build Mobile Hisab APK" workflow run karein. Successful run ke Artifacts section se Mobile-Hisab-debug-APK download ki ja sakti hai.

CAMERA
Camera permission app mein configured hai. Barcode scanning Android WebView ki browser capability par depend kar sakti hai; agar built-in scanner supported na ho, scanner button kaam nahi kar sakta. Photo OCR ke liye internet zaroori hai.

PACKAGE
Application ID: com.mobilehisab.app
Minimum Android: Android 7.0 (API 24)
App name: Mobile Hisab
